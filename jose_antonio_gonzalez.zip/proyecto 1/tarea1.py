import csv
csvArchivo = open('participantes_ficticios.csv')
archivo = csv.reader(csvArchivo,delimiter=",")

alumnos = []

for f in archivo:
    #print("Nombre: "+f[0]+ " Apellido: "+f[1])
    alumnos.append((f[0], f[1]))


for i in range(len(alumnos)):
    for j in range(0, len(alumnos) - i - 1):
        #vamos dejando los de mayor apellido los ultimos
        if alumnos[j][1] > alumnos[j + 1][1]:
            alumnos[j], alumnos[j + 1] = alumnos[j + 1], alumnos[j]


for alumno in alumnos:
    print( alumno[1] + ", " + alumno[0])


